A Python 3 compatible program that implements Link Communities.
For the paper see: http://www.nature.com/nature/journal/v466/n7307/full/nature09182.html
I modified the code of Yong-Yeol Ahn and James Bagrow so that it works
with Python 3 and can be used with networkx graphs (through a wrapper).

Using this code requires Python 3 and networkx 1.9+. 